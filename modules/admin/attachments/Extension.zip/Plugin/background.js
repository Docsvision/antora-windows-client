var port = null;

function onNativeMessage(message) {
}

function onDisconnected() {
  	port = null;
}

function connect() {
  	var hostName = "com.docsvision.navigator";
  	port = chrome.runtime.connectNative(hostName);
  	port.onMessage.addListener(onNativeMessage);
  	port.onDisconnect.addListener(onDisconnected);
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (sender.tab) {
		connect();
		port.postMessage(request);

		chrome.tabs.remove(sender.tab.id);
	}
});
