if (document.visibilityState != "prerender") {
	var navigator = document.getElementById("Navigator");
	var content = document.getElementById("Content");

	if (navigator != null && content != null && document.title && document.title.includes("Docsvision")) {
		var params = document.getElementsByTagName("param");
		var paramsMessage = "";

		for (var i = 0; i < params.length; i++) {
			var parameter = params[i];
			if (typeof parameter.value === "undefined" || parameter.value === "") {
				continue;
			}

			paramsMessage += parameter.name + "&" + parameter.value + "&";
		};

		if (params.length > 0 && paramsMessage !== "") {
			chrome.runtime.sendMessage(paramsMessage);
		}
	}
}